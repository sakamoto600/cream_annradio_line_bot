'use strict';
const crypto = require('crypto');
const line = require('@line/bot-sdk');
const client = new line.Client({channelAccessToken: process.env.ACCESSTOKEN});
exports.handler = function (event, context) {
 let signature = crypto.createHmac('sha256', process.env.CHANNELSECRET).update(event.body).digest('base64');
 let checkHeader = (event.headers || {})['X-Line-Signature'];
 let body = JSON.parse(event.body);
 if (signature === checkHeader) {
  // lineの接続チェック用
  if (body.events[0].replyToken === '00000000000000000000000000000000') {
   let lambdaResponse = {
    statusCode: 200,
    headers: { "X-Line-Status" : "OK"},
    body: '{"result":"connect check"}'
   };
   context.succeed(lambdaResponse);
  } else {
   let text = body.events[0].message.text;
   let message;
   var uedaMeigen = [
    "斯様に思います～",
    "俺マザー・テレサかって言われるわ！優しすぎて",
    "俺をいじるな、だが興味を持て",
    "まぁでも要は数字よ。",
    "いやいやいやお前はゴミだよ。",
    "(番組ディレクターに対して)コイツら『モー娘。』より入れ替わり激しいからね",
    "やかましいったらありゃしないよ！",
    "昭和の文豪か！",
    "ラジオネームせんずり、ん？　あーせんずり",
    "なんだこのわがまま放題。かぐや姫か。",
    "お前は名字を「支離」名前を「滅裂」にしろ。",
    "マラドーナ一家か！",
    "レディース&ジェントルメンうんこを漏らした奴がいる",
    "鎌倉の末期と考えてもらってかまわんよ。",
    "ナイフorフォーク？",
    "上田の押し売りです。",
    "まめひろくーん、上田ですー。",
    "満タンなるまで４、５０分",
    "スッポン屋『ウエッポン』オープン。お前ら明日学校で3人に勧めろよ〜",
    "ほら、ね？なんのほらだ！",
    "(パワプロしながらビンビンになってしまった有田に対して)お前のバットが一番極大だったわけだ。お前が一番の“ぶんぶん丸”だな。",
    "チンカスばぁちゃーん。上田ですー。",
    "みんなの笑顔が見られりゃいいんじゃねぇか？それで。(Wii買い占め事件)",
    "でもマックミランだからねぇ。",
    "あったかくしてねろよ～。",
    "俺イズムだもん。"
   ];
   var aritaMeigen = [
    "いやぁ、まいったね",
    "まいったね！(テノール編)",
    "まいったね。。",
    "寒いわね",
    "うーん、いや待てよ、うーん、いやまいったね",
    "あの…確認なんですけど、上田さんって有馬記念に出走してましたか…?",
    "また例のこそピンですか…",
    "僕から以上!!"
   ]
   var uedaMeigenRandom = uedaMeigen[Math.floor(Math.random() * uedaMeigen.length)];
   var aritaMeigenRandom = aritaMeigen[Math.floor(Math.random() * aritaMeigen.length)];
   if (body.events[0].message.text.indexOf('上田') !== -1){
     message = {
        "type": "text",
        "text": uedaMeigenRandom
     };
   } else if (body.events[0].message.text.indexOf('有田') !== -1){
     message = {
        "type": "text",
        "text": aritaMeigenRandom
   };
  };
   client.replyMessage(body.events[0].replyToken, message)
   .then((response) => {
    let lambdaResponse = {
     statusCode: 200,
     headers: { "X-Line-Status" : "OK"},
     body: '{"result":"completed"}'
    };
    context.succeed(lambdaResponse);
   }).catch((err) => console.log(err));
  }
 }else{
  console.log('署名エラー');
 }
};